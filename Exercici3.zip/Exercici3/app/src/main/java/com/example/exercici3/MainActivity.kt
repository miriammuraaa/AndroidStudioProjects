package com.example.exercici3

import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.util.TypedValue
import android.view.View
import android.widget.TextView
import android.widget.Toast

class MainActivity : AppCompatActivity() {
    private val TAG = "activity3"
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        Log.i(TAG, "onCreate")
        Toast.makeText(this, "onCreate", Toast.LENGTH_SHORT).show()
        Toast.makeText(this, "onCreate", Toast.LENGTH_LONG).show()
    }
/*Part 1*/
    fun onClickSuma(view: View) {
        val textView: TextView=findViewById(R.id.textView)
        val valorActual = textView.text.toString().toInt()
        textView.text = (valorActual + 1).toString()
    }

    fun onClickResta(view: View) {
        val textView: TextView=findViewById(R.id.textView)
        val valorActual = textView.text.toString().toInt()
        textView.text = (valorActual - 1).toString()
    }

    fun onClickAugmentar(view: View) {
        val textView: TextView=findViewById(R.id.textView)
        val size: Float = textView.getTextSize()
        textView.setTextSize(TypedValue.COMPLEX_UNIT_PX, size+8f);
    }


    fun onClickDisminuir(view:View){
        val textView: TextView=findViewById(R.id.textView)
        val size: Float = textView.getTextSize()
        textView.setTextSize(TypedValue.COMPLEX_UNIT_PX, size-8f);
    }

    fun onClickAmagar(view: View) {
        val textView: TextView=findViewById(R.id.textView)
        textView.visibility = View.INVISIBLE
    }

    fun onClickMostrar(view: View) {
        val textView: TextView=findViewById(R.id.textView)
        textView.visibility = View.VISIBLE
    }

    fun onClickColorDeFons(view: View) {
        /*cojemos el id del layout*/
        val layoutPrincipal = findViewById<View>(R.id.layoutPrincipal)
        /*llamamos a la funcion de generar color aleatorio*/
        val colorAleatorio = generarColorAleatorio()
        layoutPrincipal.setBackgroundColor(colorAleatorio)
    }

    fun onClickColorDelText(view: View) {
        /*cojemos el id del textView*/
        val textView = findViewById<TextView>(R.id.textView)
        /*llamamos a la funcion de generar color aleatorio*/
        val colorAleatorio = generarColorAleatorio()
        textView.setTextColor(colorAleatorio)
    }

    private fun generarColorAleatorio(): Int {
        /*genera aleatoriamente un codigo rgb, un numero entre el 0 y el 255 para cada posicion*/
        val r = (0..255).random()
        val g = (0..255).random()
        val b = (0..255).random()
        return Color.rgb(r, g, b)
    }
    /*Part 2*/

    override fun onStart() {
        super.onStart()
        Log.i(TAG, "onStart")
        Toast.makeText(this, "onStart", Toast.LENGTH_SHORT).show()
        /*Toast.makeText(this, "onStart", Toast.LENGTH_LONG).show()*/
    }

    override fun onResume() {
        super.onResume()
        Log.i(TAG, "onResume")
        Toast.makeText(this, "onResume", Toast.LENGTH_SHORT).show()
        /*Toast.makeText(this, "onResume", Toast.LENGTH_LONG).show()*/
    }

    override fun onPause() {
        super.onPause()
        Log.d(TAG, "onPause")
        Toast.makeText(this, "onPause", Toast.LENGTH_SHORT).show()
        /*Toast.makeText(this, "onPause", Toast.LENGTH_LONG).show()*/
    }

    override fun onStop() {
        super.onStop()
        Log.i(TAG, "onStop")
        Toast.makeText(this, "onStop", Toast.LENGTH_SHORT).show()
        /*Toast.makeText(this, "onStop", Toast.LENGTH_LONG).show()*/
    }


    override fun onDestroy() {
        super.onDestroy()
        Log.i(TAG, "onDestroy")
        Toast.makeText(this, "onDestroy", Toast.LENGTH_SHORT).show()
        /*Toast.makeText(this, "onDestroy", Toast.LENGTH_LONG).show()*/


    }

    override fun onSaveInstanceState(outState: Bundle) {
        val textView: TextView=findViewById(R.id.textView)
        val layoutPrincipal = findViewById<View>(R.id.layoutPrincipal)
        super.onSaveInstanceState(outState)

        val backgroundColor = layoutPrincipal.background
        if (backgroundColor is ColorDrawable) {
            val color = backgroundColor.color
            outState.putInt("ColorBackground",color)
        }
        outState.putString("numero",textView.text.toString())
        outState.putFloat("midaText",textView.getTextSize())
        outState.putInt("visibilitat",textView.visibility)
        outState.putInt("colortext",textView.currentTextColor)


    }
    override fun onRestoreInstanceState(savedInstanceState: Bundle) {
        val textView: TextView=findViewById(R.id.textView)
        val layoutPrincipal = findViewById<View>(R.id.layoutPrincipal)
        super.onRestoreInstanceState(savedInstanceState)
        val numero:String=savedInstanceState.getString("numero","")
        textView.text=numero
        val midaText:Float=savedInstanceState.getFloat("midaText",)
        textView.setTextSize(TypedValue.COMPLEX_UNIT_PX, midaText);
        val visibiltat : Int=savedInstanceState.getInt(("visibilitat"))
        textView.visibility=visibiltat
        val colorText : Int=savedInstanceState.getInt("colortext")
        textView.setTextColor(colorText)
        val colorBackground:Int=savedInstanceState.getInt("ColorBackground",)
        layoutPrincipal.setBackgroundColor(colorBackground)

    }

}
